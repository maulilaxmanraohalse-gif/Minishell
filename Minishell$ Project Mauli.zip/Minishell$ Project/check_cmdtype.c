#include "main.h"                                      

int check_command_type(char *command)                  // Check whether command is builtin or external
{
    char *builtins[] =                                  // Create an array of builtin commands
    {
        "echo","printf","read","cd","pwd","pushd","popd","dirs","let","eval","set","unset","export","declare",
        "typeset","readonly","getopts","source","exit","exec","shopt","caller","true","type","hash","bind",
        "help","jobs","fg","bg",NULL
    };                                                  // End the builtin command list

    int i;                                              // Declare loop variable

    for(i = 0; builtins[i] != NULL; i++)                // Loop through all builtin commands
    {
        if(strcmp(command, builtins[i]) == 0)           // Compare entered command with builtin command
        {
            return BUILTIN;                             // Return BUILTIN if command matches
        }
    }

    extract_external_commands(externalcmds);            // Read external commands from the file

    for(i = 0; externalcmds[i] != NULL; i++)            // Loop through all external commands
    {
        if(strcmp(command, externalcmds[i]) == 0)       // Compare entered command with external command
        {
            return EXTERNAL;                            // Return EXTERNAL if command matches
        }
    }

    char *path = getenv("PATH");                        // Get the PATH environment variable

    if(path != NULL)                                    // Check whether PATH is available
    {
        char path_copy[4096];                           // Create a buffer to store PATH

        strcpy(path_copy, path);                        // Copy PATH into the local buffer

        char *dir = strtok(path_copy, ":");             // Get the first directory from PATH

        while(dir != NULL)                              // Loop through all PATH directories
        {
            char fullpath[PATH_MAX];                    // Create a buffer for complete command path

            snprintf(fullpath,                         // Create the complete path of the command
                     sizeof(fullpath),
                     "%s/%s",
                     dir,
                     command);

            if(access(fullpath, X_OK) == 0)              // Check whether the command is executable
            {
                return EXTERNAL;                        // Return EXTERNAL if command is found
            }

            dir = strtok(NULL, ":");                    // Get the next PATH directory
        }
    }

    return NO_COMMAND;                                  // Return NO_COMMAND if command is not found
}


void extract_external_commands(char **external_commands) // Read external commands from the file
{
    FILE *fp;                                            // Declare a file pointer

    fp = fopen("externalcmds.txt", "r");                 // Open externalcmds.txt in read mode

    if(fp == NULL)                                       // Check whether the file opened successfully
    {
        return;                                          // Return if the file cannot be opened
    }

    char buff[256];                                      // Create a buffer to store command

    int i = 0;                                           // Initialize command index

    while(i < 199 && fgets(buff, sizeof(buff), fp) != NULL) // Read commands line by line
    {
        buff[strcspn(buff, "\r\n")] = '\0';              // Remove newline character

        trim_spaces(buff);                              // Remove leading and trailing spaces

        if(buff[0] == '\0')                              // Check whether the command is empty
        {
            continue;                                    // Skip the empty line
        }

        external_commands[i] = malloc(strlen(buff) + 1); // Allocate memory for command

        if(external_commands[i] == NULL)                // Check whether memory allocation succeeded
        {
            perror("malloc");                            // Print memory allocation error
            fclose(fp);                                   // Close the file
            return;                                       // Exit the function
        }

        strcpy(external_commands[i], buff);              // Copy command into allocated memory

        i++;                                              // Move to the next command position
    }

    external_commands[i] = NULL;                         // Mark the end of the command array

    fclose(fp);                                          // Close the external commands file
}