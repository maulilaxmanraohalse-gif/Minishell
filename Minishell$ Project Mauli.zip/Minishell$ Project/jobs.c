#include "main.h"                                      // Include the main header file

typedef struct                                          // Define a structure for storing job information
{
    pid_t pid;                                          // Store the process ID of the job
    char command[MINISHELL_MAX_INPUT];                  // Store the command name
    int active;                                         // Store whether the job is active
} Job;                                                  // Give the structure the name Job

static Job jobs[MAX_JOBS];                              // Create an array to store jobs
static int job_count = 0;                               // Store the number of jobs


void add_job(pid_t pid, char *command)                  // Add a stopped process to job list
{
    if(job_count >= MAX_JOBS)                           // Check maximum job limit
    {
        printf("Maximum jobs reached\n");               // Display maximum jobs message
        return;                                         // Return without adding job
    }

    jobs[job_count].pid = pid;                          // Store process ID

    strncpy(jobs[job_count].command,                    // Copy command into job structure
            command,
            MINISHELL_MAX_INPUT - 1);

    jobs[job_count].command[MINISHELL_MAX_INPUT - 1] = '\0'; // Add null character

    jobs[job_count].active = 1;                         // Mark job as active

    job_count++;                                        // Increase job count
}


void print_jobs(void)                                     // Display all active jobs
{
    int found = 0;                                      // Initialize job found flag

    for(int i = 0; i < job_count; i++)                  // Loop through all jobs
    {
        if(jobs[i].active)                              // Check whether job is active
        {
            printf("[%d] %d %s\n",                     // Display job number, PID and command
                   i + 1,
                   jobs[i].pid,
                   jobs[i].command);

            found = 1;                                  // Mark that a job was found
        }
    }

    if(!found)                                          // Check whether no active job exists
    {
        printf("No jobs\n");                             // Display no jobs message
    }
}


void execute_fg(void)                                   // Bring latest job to foreground
{
    int index = -1;                                     // Initialize job index

    for(int i = job_count - 1; i >= 0; i--)             // Search from latest job
    {
        if(jobs[i].active)                              // Check active job
        {
            index = i;                                  // Store latest active job index
            break;                                      // Stop searching
        }
    }

    if(index == -1)                                     // Check whether no job exists
    {
        printf("fg: no current job\n");                 // Display error message
        return;                                         // Return to shell
    }

    if(kill(jobs[index].pid, SIGCONT) == -1)             // Continue the stopped process
    {
        perror("fg");                                   // Display error message
        return;                                         // Return to shell
    }

    int status;                                         // Store process status

    if(waitpid(jobs[index].pid,                       // Wait for foreground process
               &status,
               WUNTRACED) == -1)
    {
        perror("fg");                                   // Display wait error
        return;                                         // Return to shell
    }

    if(WIFSTOPPED(status))                              // Check whether Ctrl+Z stopped process again
    {
        jobs[index].active = 1;                         // Keep job active

        last_status = 128 + WSTOPSIG(status);           // Store stopped status
    }
    else                                                // Process finished
    {
        jobs[index].active = 0;                         // Mark job as inactive

        if(WIFEXITED(status))                           // Check normal process exit
        {
            last_status = WEXITSTATUS(status);          // Store exit status
        }
        else if(WIFSIGNALED(status))                    // Check signal termination
        {
            last_status = 128 + WTERMSIG(status);       // Store signal status
        }
    }
}


void execute_bg(void)                                   // Continue latest job in background
{
    int index = -1;                                     // Initialize job index

    for(int i = job_count - 1; i >= 0; i--)             // Search from latest job
    {
        if(jobs[i].active)                              // Check active job
        {
            index = i;                                  // Store latest active job
            break;                                      // Stop searching
        }
    }

    if(index == -1)                                     // Check whether no job exists
    {
        printf("bg: no current job\n");                 // Display error message
        return;                                         // Return to shell
    }

    if(kill(jobs[index].pid, SIGCONT) == -1)             // Continue stopped process
    {
        perror("bg");                                   // Display error message
        return;                                         // Return to shell
    }

    printf("[%d] %d continued in background\n",         // Display background job information
           index + 1,
           jobs[index].pid);

    last_status = 0;                                    // Set successful status
}