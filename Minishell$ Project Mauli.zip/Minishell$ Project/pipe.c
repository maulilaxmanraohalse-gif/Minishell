#include "main.h"                                      // Include the main header file

void trim_spaces(char *str)                            // Remove leading and trailing spaces
{
    char *start;                                       // Declare pointer for starting position
    char *end;                                         // Declare pointer for ending position

    if(str == NULL)                                    // Check whether string is NULL
        return;                                        // Return if string is NULL

    start = str;                                       // Set start pointer

    while(*start == ' ' || *start == '\t')             // Skip leading spaces and tabs
        start++;                                       // Move start pointer

    if(*start == '\0')                                 // Check whether string is empty
    {
        str[0] = '\0';                                 // Make string empty
        return;                                        // Return
    }

    end = start + strlen(start) - 1;                   // Set end pointer

    while(end > start &&
          (*end == ' ' || *end == '\t'))               // Remove trailing spaces
    {
        end--;                                         // Move end pointer backward
    }

    *(end + 1) = '\0';                                 // Add null character

    if(start != str)                                   // Check whether leading spaces exist
    {
        memmove(str, start, strlen(start) + 1);        // Move trimmed string
    }
}


int check_pipe(char *input_string)                     // Check whether pipe exists
{
    if(input_string == NULL)                            // Check NULL input
        return 0;                                       // Return false

    return strchr(input_string, '|') != NULL;           // Return true if pipe found
}


void execute_npipe(char *input_string)                  // Execute multiple pipe commands
{
    char temp[MINISHELL_MAX_INPUT];                     // Temporary input buffer

    char *commands[MAX_COMMANDS];                       // Store individual commands

    pid_t pids[MAX_COMMANDS];                           // Store child PIDs

    int pipefd[MAX_COMMANDS - 1][2];                    // Store pipe file descriptors

    int command_count = 0;                              // Initialize command count

    strcpy(temp, input_string);                         // Copy input string

    char *token = strtok(temp, "|");                    // Split commands using pipe

    while(token != NULL &&
          command_count < MAX_COMMANDS)
    {
        trim_spaces(token);                             // Remove spaces

        if(token[0] == '\0')                            // Check empty command
        {
            printf("Invalid pipe\n");                   // Display error
            last_status = 2;                            // Set error status
            return;                                     // Stop execution
        }

        commands[command_count] = token;                // Store command

        command_count++;                                // Increase command count

        token = strtok(NULL, "|");                      // Get next command
    }

    if(command_count < 2)                               // At least two commands required
    {
        printf("Invalid pipe\n");                       // Display error
        last_status = 2;                                // Set error status
        return;                                         // Stop execution
    }

    /* Create pipes */
    for(int i = 0; i < command_count - 1; i++)
    {
        if(pipe(pipefd[i]) == -1)                       // Create pipe
        {
            perror("pipe");                             // Display error
            last_status = 1;                            // Set error status
            return;                                     // Stop execution
        }
    }

    /* Create child processes */
    for(int i = 0; i < command_count; i++)
    {
        pids[i] = fork();                               // Create child

        if(pids[i] < 0)                                 // Check fork error
        {
            perror("fork");                             // Display error
            last_status = 1;                            // Set error status
            return;                                     // Stop execution
        }

        if(pids[i] == 0)                                // Child process
        {
            char *argv[MAX_ARGS];                       // Argument array
            int argc = 0;                               // Argument count

            /* Input from previous pipe */
            if(i > 0)
            {
                if(dup2(pipefd[i - 1][0], STDIN_FILENO) == -1)
                {
                    perror("dup2");
                    _exit(1);
                }
            }

            /* Output to next pipe */
            if(i < command_count - 1)
            {
                if(dup2(pipefd[i][1], STDOUT_FILENO) == -1)
                {
                    perror("dup2");
                    _exit(1);
                }
            }

            /* Close all pipe descriptors */
            for(int j = 0; j < command_count - 1; j++)
            {
                close(pipefd[j][0]);
                close(pipefd[j][1]);
            }

            /* Get command arguments */
            char *arg = strtok(commands[i], " \t");

            while(arg != NULL && argc < MAX_ARGS - 1)
            {
                /* Remove single quotes */
                int len = strlen(arg);

                if(len >= 2 &&
                   arg[0] == '\'' &&
                   arg[len - 1] == '\'')
                {
                    arg[len - 1] = '\0';
                    arg++;
                }

                argv[argc] = arg;
                argc++;

                arg = strtok(NULL, " \t");
            }

            argv[argc] = NULL;                          // End argv array

            if(argv[0] == NULL)                         // Check empty command
                _exit(0);

            /* Execute command */
            execvp(argv[0], argv);

            perror("execvp");                           // Command execution error
            _exit(127);                                 // Command not found
        }
    }

    /* Parent closes all pipe descriptors */
    for(int i = 0; i < command_count - 1; i++)
    {
        close(pipefd[i][0]);
        close(pipefd[i][1]);
    }

    /* Wait for all child processes */
    int status = 0;

    for(int i = 0; i < command_count; i++)
    {
        waitpid(pids[i], &status, 0);
    }

    /* Store last command status */
    if(WIFEXITED(status))
        last_status = WEXITSTATUS(status);
    else
        last_status = 1;
}