#include "main.h"                                      // Include the main header file

char *get_command(char *input_string)                  // Extract the command from input
{
    static char command[50];                            // Create buffer to store command

    command[0] = '\0';                                  // Clear the command buffer

    sscanf(input_string, "%49s", command);              // Read first word from input

    return command;                                     // Return extracted command
}


/* echo */
void echo(char *input_string)                           // Execute echo command
{
    char *ptr = input_string + 4;                       // Skip "echo"

    while(*ptr == ' ' || *ptr == '\t')                  // Skip spaces and tabs
    {
        ptr++;                                          // Move to next character
    }

    if(strcmp(ptr, "$?") == 0)                          // Check for last status
    {
        printf("%d\n", last_status);                    // Print last command status
    }
    else if(strcmp(ptr, "$$") == 0)                     // Check for process ID
    {
        printf("%d\n", getpid());                       // Print shell process ID
    }
    else if(strcmp(ptr, "$SHELL") == 0)                 // Check for SHELL variable
    {
        char *shell = getenv("SHELL");                  // Get SHELL environment variable

        if(shell != NULL)                               // Check whether SHELL exists
        {
            printf("%s\n", shell);                      // Print shell path
        }
        else                                             // Execute when SHELL is not available
        {
            printf("/bin/sh\n");                        // Print default shell path
        }
    }
    else                                                // Execute normal echo
    {
        printf("%s\n", ptr);                             // Print entered text
    }

    last_status = 0;                                    // Set successful status
}


/* Execute internal commands */
void execute_internal_commands(char *input_string)      // Execute builtin commands
{
    char command[50];                                   // Create buffer for command

    sscanf(input_string, "%49s", command);              // Extract command name

    if(strcmp(command, "pwd") == 0)                     // Check for pwd command
    {
        char cwd[MINISHELL_MAX_INPUT];                  // Create buffer for current directory

        if(getcwd(cwd, sizeof(cwd)) != NULL)             // Get current working directory
        {
            printf("%s\n", cwd);                        // Print current directory
            last_status = 0;                            // Set successful status
        }
        else                                            // Execute when getcwd fails
        {
            perror("pwd");                              // Print error message
            last_status = 1;                            // Set failure status
        }
    }

    else if(strcmp(command, "cd") == 0)                 // Check for cd command
    {
        char *path = input_string + 2;                  // Skip "cd"

        while(*path == ' ' || *path == '\t')             // Skip spaces and tabs
        {
            path++;                                     // Move to next character
        }

        if(*path == '\0')                               // Check whether path is missing
        {
            path = getenv("HOME");                      // Use HOME directory
        }

        if(path != NULL && chdir(path) == 0)            // Change directory
        {
            last_status = 0;                            // Set successful status
        }
        else                                            // Execute when chdir fails
        {
            perror("cd");                               // Print error message
            last_status = 1;                            // Set failure status
        }
    }

    else if(strcmp(command, "echo") == 0)               // Check for echo command
    {
        echo(input_string);                              // Call echo function
    }

    else if(strcmp(command, "exit") == 0)               // Check for exit command
    {
        printf("exit\n");                               // Display exit message
        exit(0);                                        // Exit minishell
    }

    else if(strcmp(command, "jobs") == 0)               // Check for jobs command
    {
        print_jobs();                                   // Display active jobs
        last_status = 0;                                // Set successful status
    }

    else if(strcmp(command, "fg") == 0)                 // Check for fg command
    {
        execute_fg();                                   // Bring latest job to foreground
    }

    else if(strcmp(command, "bg") == 0)                 // Check for bg command
    {
        execute_bg();                                   // Continue latest job in background
    }

    else if(strcmp(command, "true") == 0)               // Check for true command
    {
        last_status = 0;                                // Set successful status
    }

    else if(strcmp(command, "printf") == 0)             // Check for printf command
    {
        char *ptr = input_string + 6;                   // Skip "printf"

        while(*ptr == ' ' || *ptr == '\t')              // Skip spaces and tabs
        {
            ptr++;                                      // Move to next character
        }

        printf("%s", ptr);                              // Print the text
        last_status = 0;                                // Set successful status
    }

    else                                                // Handle unknown builtin
    {
        printf("%s: builtin command\n", command);       // Display builtin message
        last_status = 0;                                // Set successful status
    }
}


/* Execute external command */
void execute_external_command(char *input_string)       // Execute external Linux command
{
    char temp[MINISHELL_MAX_INPUT];                     // Create temporary input buffer
    char *argv[MAX_ARGS];                               // Create argument array
    int argc = 0;                                       // Initialize argument count

    strcpy(temp, input_string);                         // Copy input into temporary buffer

    char *token = strtok(temp, " \t");                  // Get first token

    while(token != NULL && argc < MAX_ARGS - 1)         // Read all command arguments
    {
        argv[argc] = token;                              // Store argument
        argc++;                                         // Increase argument count

        token = strtok(NULL, " \t");                   // Get next argument
    }

    argv[argc] = NULL;                                  // Mark end of argv array

    if(argc == 0)                                       // Check for empty command
    {
        return;                                         // Return without execution
    }

    pid_t pid = fork();                                 // Create child process

    if(pid < 0)                                         // Check fork failure
    {
        perror("fork");                                 // Display fork error
        last_status = 1;                                // Set failure status
        return;                                         // Return to shell
    }

    if(pid == 0)                                        // Execute inside child
    {
        signal(SIGINT, SIG_DFL);                        // Enable default Ctrl+C behavior
        signal(SIGTSTP, SIG_DFL);                       // Enable default Ctrl+Z behavior

        execvp(argv[0], argv);                          // Execute external command

        perror("execvp");                               // Display exec error
        _exit(127);                                     // Exit child on exec failure
    }

    int status;                                         // Store child process status

    if(waitpid(pid, &status, WUNTRACED) == -1)          // Wait and detect stopped process
    {
        perror("waitpid");                              // Display wait error
        last_status = 1;                                // Set failure status
        return;                                         // Return to shell
    }

    if(WIFEXITED(status))                               // Check normal process exit
    {
        last_status = WEXITSTATUS(status);              // Store exit status
    }
    else if(WIFSIGNALED(status))                        // Check signal termination
    {
        last_status = 128 + WTERMSIG(status);           // Store signal status
    }
    else if(WIFSTOPPED(status))                         // Check Ctrl+Z stopped process
    {
        add_job(pid, input_string);                     // Add stopped process to job list

        printf("\n[%d] Stopped %s\n",                   // Display stopped job
               pid,
               input_string);

        last_status = 128 + WSTOPSIG(status);            // Store stopped status
    }
}