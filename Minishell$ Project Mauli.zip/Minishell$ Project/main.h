#ifndef MAIN_H
#define MAIN_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdio_ext.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>
#include <limits.h>
#include <errno.h>

#define BUILTIN     1
#define EXTERNAL    2
#define NO_COMMAND  3

#define MINISHELL_MAX_INPUT 1024
#define MAX_ARGS 100
#define MAX_COMMANDS 10
#define MAX_JOBS 20

extern char prompt[50];
extern char **externalcmds;
extern int last_status;

/* scan.c */
void scan_input(char *prompt, char *input_string);

/* command.c */
char *get_command(char *input_string);
void execute_internal_commands(char *input_string);
void execute_external_command(char *input_string);
void echo(char *input_string);

/* check_cmdtype.c */
int check_command_type(char *command);
void extract_external_commands(char **external_commands);

/* pipe.c */
int check_pipe(char *input_string);
void execute_npipe(char *input_string);
void trim_spaces(char *str);

/* signal.c */
void signal_handler(int sig_num);
void register_signal_handlers(void);

/* jobs.c */
void add_job(pid_t pid, char *command);
void print_jobs(void);
void execute_fg(void);
void execute_bg(void);

#endif