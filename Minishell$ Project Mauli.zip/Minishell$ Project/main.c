/* Name:- Mauli
Date:- 31-08-2026
Batch:- 26001B
Project Name:- Minishell$
Project Description:- Minishell is a Linux-based command-line shell developed using C programming. It allows users
to execute built-in as well as external Linux commands through a simple shell interface. The project implements
important Linux system programming concepts such as process creation, process execution, signal handling, pipes,
and job control.
The shell supports built-in commands like cd, pwd, echo, printf, exit, jobs, fg, bg, and true. External commands 
are executed using fork() and execvp(). It also supports multiple commands using pipes, handles Ctrl+C and Ctrl+Z,
 and provides basic foreground and background process management. */



#include "main.h"                                      // Include the main header file

char prompt[50] = "\033[1;34mminishell$\033[0m ";                       // Initialize the minishell prompt
char **externalcmds = NULL;                            // Declare pointer for external commands
int last_status = 0;                                   // Store the status of the last executed command

int main(void)                                          // Start the main function
{
    char input_string[MINISHELL_MAX_INPUT];             // Create buffer to store user input

    system("clear");                                    // Clear the terminal screen

    externalcmds = calloc(200, sizeof(char *));         // Allocate memory for external command list

    if(externalcmds == NULL)                             // Check whether memory allocation failed
    {
        perror("calloc");                               // Display memory allocation error
        return 1;                                       // Terminate program with failure status
    }

    register_signal_handlers();                         // Register SIGINT and SIGTSTP signal handlers

    scan_input(prompt, input_string);                   // Start reading and processing user commands

    for(int i = 0; externalcmds[i] != NULL; i++)         // Loop through all allocated external commands
    {
        free(externalcmds[i]);                           // Free memory allocated for each command
    }

    free(externalcmds);                                  // Free the external command array

    return 0;                                            // Terminate the program successfully
}