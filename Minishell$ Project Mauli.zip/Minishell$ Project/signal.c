#include "main.h"                                      // Include the main header file

void signal_handler(int sig_num)                       // Handle signals received by the shell
{
    if(sig_num == SIGINT)                              // Check whether Ctrl+C generated SIGINT
    {
        printf("\n");                                  // Move to the next line
        printf("%s", prompt);                          // Display the shell prompt again
        fflush(stdout);                                // Immediately display the prompt
    }
    else if(sig_num == SIGTSTP)                        // Check whether Ctrl+Z generated SIGTSTP
    {
        printf("\n");                                  // Move to the next line
        printf("%s", prompt);                          // Display the shell prompt again
        fflush(stdout);                                // Immediately display the prompt
    }
}


void register_signal_handlers(void)                    // Register signal handlers for the shell
{
    signal(SIGINT, signal_handler);                    // Register handler for Ctrl+C
    signal(SIGTSTP, signal_handler);                   // Register handler for Ctrl+Z
}