#include "main.h"                                      // Include the main header file

void scan_input(char *prompt, char *input_string)       // Read and process user input
{
    while(1)                                            // Run the shell continuously
    {
        printf("%s", prompt);                           // Display the shell prompt
        fflush(stdout);                                 // Immediately display the prompt

        if(fgets(input_string,                    // Read input from standard input
                 MINISHELL_MAX_INPUT,
                 stdin) == NULL)                       // Check for EOF or input error
        {
            printf("\n");                               // Print a new line before exiting
            break;                                      // Exit the shell input loop
        }

        input_string[strcspn(input_string, "\n")] = '\0'; // Remove the newline character

        if(input_string[0] == '\0')                      // Check whether input is empty
        {
            continue;                                   // Ask for input again
        }

        /* PS1 */
        if(strncmp(input_string, "PS1=", 4) == 0)        // Check whether input is a PS1 assignment
        {
            if(strchr(input_string + 4, ' ') != NULL || // Check for spaces in PS1 value
               strchr(input_string + 4, '\t') != NULL)   // Check for tabs in PS1 value
            {
                printf("Space is not allowed in PS1\n"); // Display PS1 space error
                last_status = 1;                        // Set command status to failure
            }
            else                                        // Execute when PS1 has no spaces
            {
                strcpy(prompt, input_string + 4);       // Copy the new prompt value
                strcat(prompt, " ");                    // Add a space after the prompt
                last_status = 0;                        // Set command status to success
            }

            continue;                                   // Wait for the next command
        }

        /* Pipe */
        if(check_pipe(input_string))                     // Check whether input contains a pipe
        {
            execute_npipe(input_string);                // Execute commands connected by pipes
            continue;                                   // Wait for the next command
        }

        /* Get command */
        char temp[MINISHELL_MAX_INPUT];                 // Create a temporary input buffer

        strcpy(temp, input_string);                      // Copy input into temporary buffer

        char *command = get_command(temp);              // Extract the command from input

        if(command == NULL || command[0] == '\0')        // Check whether command is empty
        {
            continue;                                   // Wait for the next command
        }

        /* Check command type */
        int ret = check_command_type(command);           // Identify the command type

        if(ret == BUILTIN)                               // Check whether command is builtin
        {
            execute_internal_commands(input_string);     // Execute the builtin command
        }
        else if(ret == EXTERNAL)                         // Check whether command is external
        {
            execute_external_command(input_string);      // Execute the external command
        }
        else                                            // Execute when command is not found
        {
            printf("%s: Command not found\n", command);  // Display command-not-found message
            last_status = 127;                           // Set status to command-not-found
        }
    }
}